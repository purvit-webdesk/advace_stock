/**
 * 2007-2021 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author    PrestaShop SA <contact@prestashop.com>
 *  @copyright 2007-2021 PrestaShop SA
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
*/

$(document).ready(function () {

    var arr_product_id = [];

    $('#scan_name').on('input', function(){
        var val = $(this).val().trim();
        val = val.replace(/\s+/g, '');

        $('.manage_quantity_block').hide();
        $('.error_msg').html('');

        if (val.length >= 3) {
            var search = $(this).val(); // this.value
            var token = find_product_token;
            $.ajax({ 
                url: find_product,
                type: 'POST',
                data: {
                    ajax: true,
                    token: token, 
                    search: search 
                },
                beforeSend: function(){
                    $('#loader').addClass('loading');
                },
                success: function (data) {

                    data = JSON.parse(data);
                    if (data.found == true) {
                        $('.error_msg').html('');

                        var simple_product_length = data.simple_product_data.length;
                        var combination_product_length = data.combination_product_data.length;

                        if (data.type == 'simple') {

                            $("#product_list").empty();
                            $("#product_list").append("<option value=''>Select Product</option>");

                            if (simple_product_length > 0) {
                                for (var i = 0; i < simple_product_length; i++) {
                                    var id = data.simple_product_data[i]['id'];
                                    var name = data.simple_product_data[i]['name'];
                                    var reference = data.simple_product_data[i]['reference'];
                                    var quantity = data.simple_product_data[i]['quantity'];
                                    var value = id+"|"+reference+"|"+quantity;

                                    $("#product_list").append('<option value="'+value+'">'+name+'</option>');
                                }
                            }

                            $('.products').show();
                            $('.combinations').hide();

                        }else if(data.type == 'combination'){

                            $("#combination_list").empty();
                            $("#combination_list").append("<option value=''>Select Combination</option>");

                            if (combination_product_length > 0) {
                                for (var i = 0; i < combination_product_length; i++) {
                                    var id = data.combination_product_data[i]['attribute_id'];
                                    var name = data.combination_product_data[i]['name'];
                                    var combination_name = data.combination_product_data[i]['combination_name'];
                                    var reference = data.combination_product_data[i]['reference'];
                                    var quantity = data.combination_product_data[i]['quantity'];
                                    var product_id = data.combination_product_data[i]['id'];
                                    var value = id+"|"+reference+"|"+quantity+'|'+name+'|'+combination_name+'|'+product_id;

                                    $("#combination_list").append('<option value="'+value+'">'+name+' ('+ combination_name +')</option>');
                                }
                            }

                            $('.combinations').show();
                            $('.products').hide();
                        }else{
                            $("#product_list").empty();
                            $("#product_list").append("<option value=''>Select Product</option>");

                            if (simple_product_length > 0) {
                                for (var i = 0; i < simple_product_length; i++) {
                                    var id = data.simple_product_data[i]['id'];
                                    var name = data.simple_product_data[i]['name'];
                                    var reference = data.simple_product_data[i]['reference'];
                                    var quantity = data.simple_product_data[i]['quantity'];
                                    var value = id+"|"+reference+"|"+quantity;

                                    $("#product_list").append('<option value="'+value+'">'+name+'</option>');
                                }
                            }

                            $("#combination_list").empty();
                            $("#combination_list").append("<option value=''>Select Combination</option>");

                            if (combination_product_length > 0) {
                                for (var i = 0; i < combination_product_length; i++) {
                                    var id = data.combination_product_data[i]['attribute_id'];
                                    var name = data.combination_product_data[i]['name'];
                                    var combination_name = data.combination_product_data[i]['combination_name'];
                                    var reference = data.combination_product_data[i]['reference'];
                                    var quantity = data.combination_product_data[i]['quantity'];
                                    var product_id = data.combination_product_data[i]['id'];
                                    var value = id+"|"+reference+"|"+quantity+'|'+name+'|'+combination_name+'|'+product_id;

                                    $("#combination_list").append('<option value="'+value+'">'+name+' ('+ combination_name +')</option>');
                                }
                            }

                            $('.products').show();
                            $('.combinations').show();
                        }

                        setTimeout(function(){
                            $('#loader').removeClass('loading');
                            $('.manage_quantity_block').show();
                        },1000);
    
                    }else{
                        $('.products').hide();
                        $('.combinations').hide();
                        $('.manage_quantity_block').hide();

                        setTimeout(function(){
                            $('#loader').removeClass('loading');
                            $('.error_msg').html('<div class="alert alert-danger" role="alert">No Product Found</div>');
                        },1000);    
                    }
                }
            })
        }
    });

    
    $('#product_list').on('change', function() {

        $('table#quantity_preview tr#start').remove();
        $('.prod_error_msg').text('');
        if (this.value != '') {
            var val = this.value.split('|');

            var product_id = val[0];
            var reference = val[1];
            var quantity = val[2];
            var name = $("#product_list option:selected").text();
            var hidden_input_reset = '<input type="hidden" name="reset_qty[simple_'+product_id+']" class="form-control" value="0">';

            if ($('.toggle').hasClass('btn-primary')) {
                quantity = 0;
                hidden_input_reset = '<input type="hidden" name="reset_qty[simple_'+product_id+']" class="form-control" value="1">';
            }

            var qty = eval($('#qty_number').val());
            var total = Number(quantity) + Number(qty);

            var length = eval($("#quantity_preview tbody tr").length);
            length = length + 1;

            if (length > 0) {
                $('.add_stock').removeClass('disabled');
            }

            if (arr_product_id.includes('product_'+product_id)) {
                $('.prod_error_msg').text('Product already exist please try another.');
            }else{
                $('.prod_error_msg').text('');
                arr_product_id.push('product_'+product_id);

                $("#quantity_preview tbody").append('<tr class="product_'+product_id+'"><td>' + length + '</td><td>' + name + '</td><td> N/A <input type="hidden" name="comb_name[simple_'+product_id+']" class="form-control" value="N/A"></td><td>' + reference + '</td><td>' + quantity + '</td><td><input type="number" name="qty_input_text" class="input_qty form-control" value="'+qty+'" data-qty="'+quantity+'" size="5"></td><td><input type="text" id="total_qty" name="update_qty[simple_'+product_id+']" value="'+total+'" size="5" readonly>'+hidden_input_reset+'</td></tr>');
            }
        }
    });

    $('#combination_list').on('change', function() {

        $('table#quantity_preview tr#start').remove();
        $('.comb_error_msg').text('');
        if (this.value != '') {
            var comb_val = this.value.split('|');
            var product_attribute_id = comb_val[0];
            var comb_reference = comb_val[1];
            var comb_quantity = comb_val[2];
            var comb_product_name = comb_val[3];
            var comb_name = comb_val[4];
            var product_id = comb_val[5];
            var comb_hidden_input_reset = '<input type="hidden" name="reset_qty[combination_'+product_id+'_'+product_attribute_id+']" class="form-control" value="0">';

            if ($('.toggle').hasClass('btn-primary')) {
                comb_quantity = 0;
                comb_hidden_input_reset = '<input type="hidden" name="reset_qty[combination_'+product_id+'_'+product_attribute_id+']" class="form-control" value="1">';
            }

            var qty = eval($('#qty_number').val());
            var total = Number(comb_quantity) + Number(qty);

            var length = eval($("#quantity_preview tbody tr").length);
            length = length + 1;

            if (length > 0) {
                $('.add_stock').removeClass('disabled');
            }

            if (arr_product_id.includes('combination_'+product_attribute_id)) {
                $('.comb_error_msg').text('Combination already exist please try another.');
            }else{
                $('.comb_error_msg').text('');
                arr_product_id.push('combination_'+product_attribute_id);

                $("#quantity_preview tbody").append('<tr class="combination_'+product_attribute_id+'"><td>' + length + '</td><td>' + comb_product_name + '</td><td>'+comb_name+'<input type="hidden" name="comb_name[combination_'+product_id+'_'+product_attribute_id+']" class="form-control" value="'+comb_name+'"></td><td>' + comb_reference + '</td><td>' + comb_quantity + '</td><td><input type="number" name="qty_input_text" class="input_qty form-control" value="'+qty+'" data-qty="'+comb_quantity+'" size="5"></td><td><input type="text" id="total_qty" name="update_qty[combination_'+product_id+'_'+product_attribute_id+']" value="'+total+'" size="5">'+comb_hidden_input_reset+'</td></tr>');
            }
        }
    });

    $('#quantity_preview').on('input','.input_qty',function(){
        var input_qty = $(this).parent().parent('tr').find('.input_qty').val();
        var available_qty = $(this).parent().parent('tr').find('.input_qty').attr("data-qty");

        if (input_qty == '') {
            input_qty = 0;
            $(this).parent().parent('tr').find('.input_qty').val(input_qty);
        }

        $(this).parent().parent('tr').find('.input_qty').val(Number(input_qty));

        $($(this).parent().parent('tr').find('.input_qty')).focus(function(){
            if ($(this).parent().parent('tr').find('.input_qty').val() == '0') {
               $(this).parent().parent('tr').find('.input_qty').val(''); 
            }
        }).blur(function() {
            $(this).parent().parent('tr').find('.input_qty').val(Number(input_qty));
        });

        var res = Number(available_qty) + Number(input_qty);

        if (!isNaN(res)) {
            $(this).parent().parent('tr').find('#total_qty').val(res);
        }
    });

    $('.btn-undo').on('click', function() {
        var historyId = $(this).attr("id");
        var undo_stock_qty = $(this).attr('data-prev-qty');
        var undo_comb_name = $(this).attr('data-comb-name');
        var undo_reset_qty = $(this).attr('data-reset-qty');
        var undoToken = undo_token;
        $.ajax({ 
            url: undo_qty,
            type: 'POST',
            data: {
                ajax: true,
                token: undoToken, 
                "historyId": historyId,
                'undostock': undo_stock_qty,
                'undocombname': undo_comb_name,
                'undoreset': undo_reset_qty, 
                action: 'stockUndoProcess'
            },
            beforeSend: function(){
                $('#loader').addClass('loading');
            },
            success: function (data) {
                var data = JSON.parse(data);
                if(data.status == true){
                    setTimeout(function(){
                        $('#loader').removeClass('loading');
                        
                        toastr["success"]("Stock Reverted Successfully.!")

                        toastr.options = {
                            "closeButton": true,
                            "debug": false,
                            "newestOnTop": true,
                            "progressBar": true,
                            "positionClass": "toast-top-right",
                            "preventDuplicates": false,
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "slideDown",
                            "hideMethod": "slideUp",
                        }
                    },1000);
                }
            }
        });
    });
});   // EINDE DOCUMENT READY