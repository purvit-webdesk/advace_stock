<?php
/**
 * 2007-2019 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author    PrestaShop SA <contact@prestashop.com>
 *  @copyright 2007-2019 PrestaShop SA
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */

class AdminStockManageController extends ModuleAdminController
{
    public function __construct()
    {
        parent::__construct();
    }
    public function init()
    {
        parent::init();
        $this->bootstrap = true;
    }
    public function initContent()
    {
        parent::initContent();

        if ($this->context->cookie->__isset('stock_added') && $this->context->cookie->__get('stock_added') == 1) {
            $this->context->smarty->assign('confirmations', 'Stock Added Successfully..');
            $this->context->cookie->__unset('stock_added');
        }

        $sql_history = 'SELECT * FROM' . _DB_PREFIX_ . 'advanced_stock_history ORDER BY id DESC';
        $history_res = Db::getInstance()->ExecuteS($sql_history);

        $this->context->smarty->assign(
            array('history' => $history_res)
        );
        $this->setTemplate('stock.tpl');
    }

    public function postProcess()
    {

        parent::postProcess();
        
        $id_lang = (int) Configuration::get('PS_LANG_DEFAULT');

        $db = \Db::getInstance();

        if (Tools::isSubmit('AddStockSubmit')) {
            $updated_value = Tools::getValue('update_qty');
            $comb_name = Tools::getValue('comb_name');
            $reset = Tools::getValue('reset_qty');

            if (isset($updated_value) && !empty($updated_value)) {
                $insert_history = array();
                foreach ($updated_value as $id => $updated_qty) {
                    $ids = explode('_', $id);
                    $product_attribute_id = null;
                    if (isset($ids[2]) && !empty($ids[2])) {
                        $product_attribute_id = $ids[2];
                    }

                    $product_name = 'N/A';
                    $reference = 'N/A';

                    $product = new Product($ids[1], false, $id_lang);

                    if (Validate::isLoadedObject($product)) {
                        $product_name = $product->name;
                        $reference = $product->reference;
                    }

                    $quantity = (int) StockAvailable::getQuantityAvailableByProduct($ids[1], $product_attribute_id);
                    
                    $available_quantity = $quantity;
                    if ($quantity > 0) {
                        $available_quantity = $quantity;
                    }

                    $combination_name = 'N/A';
                    if (array_key_exists($id, $comb_name)) {
                        $combination_name = $comb_name[$id];
                    }

                    $reset_qty = 'N';
                    if (isset($reset) && !empty($reset) && array_key_exists($id, $reset) && $reset[$id] == 1) {
                        $reset_qty = 'Y';
                        $available_quantity = 0;
                    }

                    StockAvailable::setQuantity($ids[1], $product_attribute_id, $updated_qty);
                    
                    $insert_history[] = array(
                        'product_id' => (int) $ids[1],
                        'product_name' => pSQL($product_name),
                        'combination_name' => pSQL($combination_name),
                        'reference' => pSQL($reference),
                        'reset_qty' => $reset_qty,
                        'stock_available' => (int) $updated_qty,
                        'stock_prev' => pSQL($available_quantity),
                        'p_ids' => $id,
                        'time' => date('Y-m-d H:i:s'),
                    );
                }

                $history = $db->insert('advanced_stock_history', $insert_history);

                if ($history) {
                    $this->context->cookie->__set('stock_added', '1');
                    $this->context->cookie->write();
                    
                    $link = $this->context->link->getAdminLink('AdminStockManage');
                    Tools::redirectAdmin($link);
                }
            }
        }
    }

    public function ajaxProcessstockUndoProcess()
    {
        $id_lang = (int) Configuration::get('PS_LANG_DEFAULT');

        $db = \Db::getInstance();

        $result = array();

        $product_comb_id = Tools::getValue('historyId');
        $undo_stock_qty = Tools::getValue('undostock');

        $product_comb_id = explode('_', $product_comb_id);

        if (isset($product_comb_id) && !empty($product_comb_id)) {
            $comb_attribute_id = null;
            if (isset($product_comb_id[2]) && !empty($product_comb_id[2])) {
                $comb_attribute_id = $product_comb_id[2];
            }
        }

        $product_name = 'N/A';
        $reference = 'N/A';
        
        $product = new Product($product_comb_id[1], false, $id_lang);
        
        if (Validate::isLoadedObject($product)) {
            $product_name = $product->name;
            $reference = $product->reference;
        }

        $quantity = (int) StockAvailable::getQuantityAvailableByProduct($product_comb_id[1], $comb_attribute_id);

        $available_quantity = $quantity;
        
        if ($quantity > 0) {
            $available_quantity = $quantity;
        }

        $undo_comb_name = Tools::getValue('undocombname');
        $undo_reset_qty = Tools::getValue('undoreset');

        StockAvailable::setQuantity($product_comb_id[1], $comb_attribute_id, $undo_stock_qty);

        $insert_undo_history = array(
            'product_id' => (int) $product_comb_id[1],
            'product_name' => pSQL($product_name),
            'combination_name' => pSQL($undo_comb_name),
            'reference' => pSQL($reference),
            'reset_qty' => $undo_reset_qty,
            'stock_available' => (int) $undo_stock_qty,
            'stock_prev' => pSQL($available_quantity),
            'p_ids' => implode('_', $product_comb_id),
            'time' => date('Y-m-d H:i:s'),
        );

        $undo_history = $db->insert('advanced_stock_history', $insert_undo_history);

        if ($undo_history) {
            $result['status'] = true;
        }

        echo json_encode($result);
    }
}
