<?php
/**
 * 2007-2020 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2020 PrestaShop SA
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */

class AdminFindProductsController extends ModuleAdminController
{
    public function initContent()
    {
        $this->ajax = true;
        parent::initContent();
    }

    public function displayAjax()
    {
        $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
        include_once '../../config/config.inc.php';
        include_once '../../init.php';

        $search = Tools::getValue('search');

        if (!empty($search)) {
            $strsimplecls = ' AND (pl.name LIKE "%'.$search.'%" OR p.reference LIKE "%'.$search.'%" OR p.ean13 LIKE "%'.$search.'%" OR p.upc LIKE "%'.$search.'%") '; // phpcs:ignore

            $strcombcls = ' AND (pl.name LIKE "%'.$search.'%" OR pa.reference LIKE "%'.$search.'%" OR pa.ean13 LIKE "%'.$search.'%" OR pa.upc LIKE "%'.$search.'%") '; // phpcs:ignore
        }

        /** phpcs:disable */
        $select_simple_product = 'SELECT p.id_product,pl.name,p.reference,p.ean13,p.upc,pq.quantity FROM ' . _DB_PREFIX_ . 'product p
                                  LEFT JOIN ' . _DB_PREFIX_ . 'product_attribute pa ON (p.id_product = pa.id_product)
                                  LEFT JOIN ' . _DB_PREFIX_ . 'stock_available pq ON (p.id_product = pq.id_product AND pq.id_product_attribute = 0) 
                                  LEFT JOIN ' . _DB_PREFIX_ . 'product_lang pl ON (p.id_product = pl.id_product)
                                  WHERE pl.id_lang = '.$default_lang.' AND pa.id_product_attribute IS NULL '.$strsimplecls.'
                                  ORDER BY p.id_product ASC';

        $select_combination_product = 'SELECT p.id_product,pl.name,pa.reference,pa.ean13,pa.upc,pq.quantity,pac.id_product_attribute,GROUP_CONCAT(pal.name ORDER BY agl.id_attribute_group SEPARATOR ":") AS combination FROM ' . _DB_PREFIX_ . 'product p
            LEFT JOIN ' . _DB_PREFIX_ . 'product_attribute pa ON (p.id_product = pa.id_product)
            LEFT JOIN ' . _DB_PREFIX_ . 'stock_available pq ON (p.id_product = pq.id_product AND pa.id_product_attribute = pq.id_product_attribute)
            LEFT JOIN ' . _DB_PREFIX_ . 'product_lang pl ON (p.id_product = pl.id_product)
            LEFT JOIN ' . _DB_PREFIX_ . 'product_attribute_combination pac ON (pa.id_product_attribute = pac.id_product_attribute)
            LEFT JOIN ' . _DB_PREFIX_ . 'attribute_lang pal ON (pac.id_attribute = pal.id_attribute)
            LEFT JOIN ' . _DB_PREFIX_ . 'attribute a ON (pal.id_attribute = a.id_attribute)
            LEFT JOIN ' . _DB_PREFIX_ . 'attribute_group_lang agl ON (a.id_attribute_group = agl.id_attribute_group)
            LEFT JOIN ' . _DB_PREFIX_ . 'product_attribute_image pai ON (pa.id_product_attribute = pai.id_product_attribute)
            WHERE pl.id_lang = '.$default_lang.' AND pal.id_lang = '.$default_lang.' AND agl.id_lang = '.$default_lang.' '.$strcombcls.'
            GROUP BY pac.id_product_attribute
            ORDER BY p.id_product ASC';
        /** phpcs:enable */

        $result_simple = Db::getInstance()->ExecuteS($select_simple_product);
        $result_combination = Db::getInstance()->ExecuteS($select_combination_product);

        $result = array();

        $arr_simple = array();
        $arr_combination = array();

        if (!empty($result_simple) && !empty($result_combination)) {
            $result['found'] = true;
            $result['type'] = 'All';

            foreach ($result_simple as $s_products) {
                $arr_simple[] = array(
                    'id' => $s_products['id_product'],
                    'name' => $s_products['name'],
                    'quantity' => $s_products['quantity'],
                    'reference' => $s_products['reference']
                );
            }

            foreach ($result_combination as $c_products) {
                $arr_combination[] = array(
                    'id' => $c_products['id_product'],
                    'name' => $c_products['name'],
                    'quantity' => $c_products['quantity'],
                    'attribute_id' => $c_products['id_product_attribute'],
                    'combination_name' => $c_products['combination'],
                    'reference' => $c_products['reference']
                );
            }
        } elseif (!empty($result_simple)) {
            $result['found'] = true;
            $result['type'] = 'simple';

            foreach ($result_simple as $s_products) {
                $arr_simple[] = array(
                    'id' => $s_products['id_product'],
                    'name' => $s_products['name'],
                    'quantity' => $s_products['quantity'],
                    'reference' => $s_products['reference']
                );
            }
        } elseif (!empty($result_combination)) {
            $result['found'] = true;
            $result['type'] = 'combination';

            foreach ($result_combination as $c_products) {
                $arr_combination[] = array(
                    'id' => $c_products['id_product'],
                    'name' => $c_products['name'],
                    'quantity' => $c_products['quantity'],
                    'attribute_id' => $c_products['id_product_attribute'],
                    'combination_name' => $c_products['combination'],
                    'reference' => $c_products['reference']
                );
            }
        } else {
            $result['found'] = false;
        }

        $result['simple_product_data'] = $arr_simple;
        $result['combination_product_data'] = $arr_combination;

        echo json_encode($result);
    }
}
